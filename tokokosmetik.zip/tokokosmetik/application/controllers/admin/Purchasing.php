<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Purchasing extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("purchasing_model");
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data["purchasing"] = $this->purchasing_model->getAll();
        $this->load->view("admin/purchasing/list", $data);
    }

    public function add($id = null)
    {
        $purchasing = $this->purchasing_model;
        $validation = $this->form_validation;
        $validation->set_rules($purchasing->rules());

        if ($validation->run()) {
            $purchasing->save();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        }

        $this->load->view("admin/purchasing/new_form");
    }

    public function edit($id = null)
    {
        if (!isset($id)) redirect('admin/purchasing');
       
        $purchasing = $this->purchasing_model;
        $validation = $this->form_validation;
        $validation->set_rules($purchasing->rules());

        if ($validation->run()) {
            $purchasing->update();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        }

        $data["purchasing"] = $purchasing->getById($id);
        if (!$data["purchasing"]) show_404();
        
        $this->load->view("admin/purchasing/edit_form", $data);
    }

    public function delete($id=null)
    {
        if (!isset($id)) show_404();
        
        if ($this->purchasing_model->delete($id)) {
            redirect(site_url('admin/purchasing'));
        }
    }
}