<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class sistemintegrasi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("sistemintegrasi_model");
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data["sistemintegrasi"] = $this->sistemintegrasi_model->getAll();
        $this->load->view("admin/sistemintegrasi/list", $data);
    }

    public function add()
    {
        $sistemintegrasi = $this->sistemintegrasi_model;
        $validation = $this->form_validation;
        $validation->set_rules($sistemintegrasi->rules());

        if ($validation->run()) {
            $sistemintegrasi->save();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        }

        $this->load->view("admin/sistemintegrasi/new_form");
    }

    public function edit($id = null)
    {
        if (!isset($id)) redirect('admin/sistemintegrasi');
       
        $sistemintegrasi = $this->sistemintegrasi_model;
        $validation = $this->form_validation;
        $validation->set_rules($sistemintegrasi->rules());

        if ($validation->run()) {
            $sistemintegrasi->update();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        }

        $data["sistemintegrasi"] = $sistemintegrasi->getById($id);
        if (!$data["sistemintegrasi"]) show_404();
        
        $this->load->view("admin/sistemintegrasi/edit_form", $data);
    }

    public function delete($id=null)
    {
        if (!isset($id)) show_404();
        
        if ($this->sistemintegrasi_model->delete($id)) {
            redirect(site_url('admin/sistemintegrasi'));
        }
    }
}