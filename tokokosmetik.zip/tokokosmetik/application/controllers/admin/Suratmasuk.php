<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Suratmasuk extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("Suratmasuk_model");
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data["suratmasuk"] = $this->Suratmasuk_model->getAll();
        $this->load->view("admin/suratmasuk/list", $data);
    }

    public function add()
    {
        $suratmasuk = $this->Suratmasuk_model;
        $validation = $this->form_validation;
        $validation->set_rules($suratmasuk->rules());

        if ($validation->run()) {
            $suratmasuk->save();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        }

        $this->load->view("admin/suratmasuk/new_form");
    }

    public function edit($id = null)
    {
        if (!isset($id)) redirect('admin/suratmasuk');
       
        $suratmasuk = $this->Suratmasuk_model;
        $validation = $this->form_validation;
        $validation->set_rules($suratmasuk->rules());

        if ($validation->run()) {
            $suratmasuk->update();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        }

        $data["suratmasuk"] = $suratmasuk->getById($id);
        if (!$data["suratmasuk"]) show_404();
        
        $this->load->view("admin/suratmasuk/edit_form", $data);
    }

    public function delete($id=null)
    {
        if (!isset($id)) show_404();
        
        if ($this->Suratmasuk_model->delete($id)) {
            redirect(site_url('admin/suratmasuk'));
        }
    }
}