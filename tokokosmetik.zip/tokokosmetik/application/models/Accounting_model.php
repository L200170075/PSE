<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Accounting_model extends CI_Model
{
    private $_table = "accounting";

    public $id;
    public $nama;
    public $jumlah;
	 public $tanggal;
	 public $harga;
	 public $kosmetik;

    public function rules()
    {
        return [
            ['field' => 'nama',
            'label' => 'Nama Pembeli',
            'rules' => 'required'],

            ['field' => 'jumlah',
            'label' => 'Jumlah',
            'rules' => 'required'],

			['field' => 'tanggal',
            'label' => 'Tanggal',
            'rules' => 'required'],
			
			 ['field' => 'harga',
            'label' => 'Harga',
            'rules' => 'required'],
			
			 ['field' => 'kosmetik',
            'label' => 'Kosmetik',
            'rules' => 'required']
        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["id" => $id])->row();
    }

    public function save()
    {
        $post = $this->input->post();
        $this->id = uniqid();
        $this->nama = $post["nama"];
        $this->jumlah = $post["jumlah"];
        $this->tanggal = $post["tanggal"];
		$this->harga = $post["harga"];
		$this->kosmetik = $post["kosmetik"];
        return $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $post = $this->input->post();
        $this->id = $post["id"];
        $this->nama = $post["nama"];
        $this->jumlah = $post["jumlah"];
        $this->tanggal = $post["tanggal"];
		$this->harga = $post["harga"];
		$this->kosmetik = $post["kosmetik"];
        return $this->db->update($this->_table, $this, array('id' => $post['id']));
    }

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("id" => $id));
    }
}