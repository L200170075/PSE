<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Inventorycontrol_model extends CI_Model
{
    private $_table = "inventorycontrol";

    public $id_invent;
    public $nama_invent;
    public $kategori_invent;
    public $harga_invent;
    public $stock_invent;
	public $tglmasuk_invent;
	public $exp_invent;

    public function rules()
    {
        return [
            ['field' => 'nama_invent',
            'label' => 'Nama_invent',
            'rules' => 'required'],

            ['field' => 'kategori_invent',
            'label' => 'Kategori_invent',
            'rules' => 'required'],
            
            ['field' => 'harga_invent',
            'label' => 'Harga_invent',
            'rules' => 'required'],

            ['field' => 'stock_invent',
            'label' => 'Stock_invent',
            'rules' => 'required'],
			
			['field' => 'tglmasuk_invent',
            'label' => 'Tglmasuk_invent',
            'rules' => 'required'],
			
			['field' => 'exp_invent',
            'label' => 'Exp_invent',
            'rules' => 'required'],

        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["id_invent" => $id])->row();
    }

    public function save()
    {
        $post = $this->input->post();
        $this->id_invent = uniqid();
        $this->nama_invent = $post["nama_invent"];
        $this->kategori_invent = $post["kategori_invent"];
        $this->harga_invent = $post["harga_invent"];
        $this->stock_invent = $post["stock_invent"];
		$this->tglmasuk_invent = $post["tglmasuk_invent"];
		$this->exp_invent = $post["exp_invent"];
        return $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $post = $this->input->post();
        $this->id_invent = $post["id"];
        $this->nama_invent = $post["nama_invent"];
        $this->kategori_invent = $post["kategori_invent"];
        $this->harga_invent = $post["harga_invent"];
        $this->stock_invent = $post["stock_invent"];
		$this->tglmasuk_invent = $post["tglmasuk_invent"];
		$this->exp_invent = $post["exp_invent"];
        return $this->db->update($this->_table, $this, array('id_invent' => $post['id']));
    }

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("id_invent" => $id));
    }
}