<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Purchasing_model extends CI_Model
{
    private $_table = "purchasing";

    public $id;
    public $customer_name;
    public $date;
    public $item;

    public function rules()
    {
        return [
            ['field' => 'customer_name',
            'label' => 'Customer_name',
            'rules' => 'required'],

            ['field' => 'date',
            'label' => 'Date',
            'rules' => 'required'],
            
            ['field' => 'item',
            'label' => 'Item',
            'rules' => 'required']
        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["id" => $id])->row();
    }

    public function save()
    {
        $post = $this->input->post();
        $this->id = uniqid();
        $this->customer_name = $post["customer_name"];
        $this->date = $post["date"];
        $this->item = $post["item"];
        return $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $post = $this->input->post();
        $this->id = $post["id"];
        $this->customer_name = $post["customer_name"];
        $this->date = $post["date"];
        $this->item = $post["item"];
        return $this->db->update($this->_table, $this, array('id' => $post['id']));
    }

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("id" => $id));
    }
}