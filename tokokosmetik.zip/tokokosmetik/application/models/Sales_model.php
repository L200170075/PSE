<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_model extends CI_Model
{
    private $_table = "sales";

    public $id;
    public $namabarang;
    public $stokbarang;
    public $jumlahkeluar;
    public $stokakhir;
	 public $tanggal;

    public function rules()
    {
        return [
            ['field' => 'namabarang',
            'label' => 'Namabarang',
            'rules' => 'required'],

            ['field' => 'stokbarang',
            'label' => 'Stokbarang',
            'rules' => 'required'],
            
            ['field' => 'jumlahkeluar',
            'label' => 'Jumlahkeluar',
            'rules' => 'required'],

            ['field' => 'stokakhir',
            'label' => 'Stokakhir',
            'rules' => 'required'],
			
			['field' => 'tanggal',
            'label' => 'Tanggal',
            'rules' => 'required']
        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["id" => $id])->row();
    }

    public function save()
    {
        $post = $this->input->post();
        $this->id = uniqid();
        $this->namabarang = $post["namabarang"];
        $this->stokbarang = $post["stokbarang"];
        $this->jumlahkeluar = $post["jumlahkeluar"];
        $this->stokakhir = $post["stokakhir"];
		$this->tanggal = $post["tanggal"];
        return $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $post = $this->input->post();
        $this->id = $post["id"];
        $this->namabarang = $post["namabarang"];
        $this->stokbarang = $post["stokbarang"];
        $this->jumlahkeluar = $post["jumlahkeluar"];
        $this->stokakhir = $post["stokakhir"];
		$this->tanggal = $post["tanggal"];
        return $this->db->update($this->_table, $this, array('id' => $post['id']));
    }

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("id" => $id));
    }
}