<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Sistemintegrasi_model extends CI_Model
{
    private $_table = "sistemintegrasi";

    public $id;
    public $produk;
    public $stok;
	 public $jumlahterjual;
	 public $totalbiaya;
	 public $pengeluaran;

    public function rules()
    {
        return [
            ['field' => 'produk',
            'label' => 'Produk',
            'rules' => 'required'],

            ['field' => 'stok',
            'label' => 'Stok',
            'rules' => 'required'],

			['field' => 'jumlahterjual',
            'label' => 'JumlahTerjual',
            'rules' => 'required'],
			
			 ['field' => 'totalbiaya',
            'label' => 'TotalBiayaMasuk',
            'rules' => 'required'],
			
			 ['field' => 'pengeluaran',
            'label' => 'PengeluaranBiaya',
            'rules' => 'required']
        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["id" => $id])->row();
    }

    public function save()
    {
        $post = $this->input->post();
        $this->id = uniqid();
        $this->produk = $post["produk"];
        $this->stok = $post["stok"];
        $this->jumlahterjual = $post["jumlahterjual"];
		$this->totalbiaya = $post["totalbiaya"];
		$this->pengeluaran = $post["pengeluaran"];
        return $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $post = $this->input->post();
        $this->id = $post["id"];
        $this->produk = $post["produk"];
        $this->stok = $post["stok"];
        $this->jumlahterjual = $post["jumlahterjual"];
		$this->totalbiaya = $post["totalbiaya"];
		$this->pengeluaran = $post["pengeluaran"];
        return $this->db->update($this->_table, $this, array('id' => $post['id']));
    }

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("id" => $id));
    }
}