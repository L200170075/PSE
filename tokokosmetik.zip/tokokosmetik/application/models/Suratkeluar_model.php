<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Suratkeluar_model extends CI_Model
{
    private $_table = "suratkeluar";

    public $id_surat;
    public $tglkeluar_surat;
    public $tujuan;
    public $no_surat;
    public $tgl_surat;
	public $perihal_surat;

    public function rules()
    {
        return [
            ['field' => 'tglkeluar_surat',
            'label' => 'Tglkeluar_surat',
            'rules' => 'required'],

            ['field' => 'tujuan',
            'label' => 'Tujuan',
            'rules' => 'required'],
            
            ['field' => 'no_surat',
            'label' => 'No_surat',
            'rules' => 'required'],

            ['field' => 'tgl_surat',
            'label' => 'Tgl_surat',
            'rules' => 'required'],
			
			['field' => 'perihal_surat',
            'label' => 'erihal_surat',
            'rules' => 'required']
        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["id_surat" => $id])->row();
    }

    public function save()
    {
        $post = $this->input->post();
        $this->id_surat = uniqid();
        $this->tglkeluar_surat = $post["tglkeluar_surat"];
        $this->tujuan = $post["tujuan"];
        $this->no_surat = $post["no_surat"];
        $this->tgl_surat = $post["tgl_surat"];
		$this->perihal_surat = $post["perihal_surat"];
        return $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $post = $this->input->post();
        $this->id_surat = $post["id"];
        $this->tglkeluar_surat = $post["tglkeluar_surat"];
        $this->tujuan = $post["tujuan"];
        $this->no_surat = $post["no_surat"];
        $this->tgl_surat = $post["tgl_surat"];
		$this->perihal_surat = $post["perihal_surat"];
        return $this->db->update($this->_table, $this, array('id_surat' => $post['id']));
    }

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("id_surat" => $id));
    }
}