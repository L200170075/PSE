<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Payroll_model extends CI_Model
{
    private $_table = "payroll";

    public $namapegawai;
    public $golongan;
    public $gajipokok;
    public $tunjangan;
    public $pajak;
	public $bpjs;
	public $gajibersih;
	public $tanggal;

    public function rules()
    {
        return [
            ['field' => 'namapegawai',
            'label' => 'Namapegawai',
            'rules' => 'required'],

            ['field' => 'golongan',
            'label' => 'Golongan',
            'rules' => 'required'],
            
            ['field' => 'gajipokok',
            'label' => 'Gajipokok',
            'rules' => 'required'],

            ['field' => 'tunjangan',
            'label' => 'Tunjangan',
            'rules' => 'required'],
			
			['field' => 'pajak',
            'label' => 'Pajak',
            'rules' => 'required'],
			
			['field' => 'bpjs',
            'label' => 'Bpjs',
            'rules' => 'required'],
			
			['field' => 'gajibersih',
            'label' => 'Gajibersih',
            'rules' => 'required'],
			
			['field' => 'tanggal',
            'label' => 'Tanggal',
            'rules' => 'required'],
        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["id" => $id])->row();
    }

    public function save()
    {
        $post = $this->input->post();
        $this->id = uniqid();
        $this->namapegawai = $post["namapegawai"];
        $this->golongan = $post["golongan"];
        $this->gajipokok = $post["gajipokok"];
		$this->tunjangan = $post["tunjangan"];
		$this->pajak = $post["pajak"];
		$this->bpjs = $post["bpjs"];
		$this->gajibersih = $post["gajibersih"];
        $this->tanggal = $post["tanggal"];
        return $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $post = $this->input->post();
        $this->id = uniqid();
        $this->namapegawai = $post["namapegawai"];
        $this->golongan = $post["golongan"];
        $this->gajipokok = $post["gajipokok"];
		$this->tunjangan = $post["tunjangan"];
		$this->pajak = $post["pajak"];
		$this->bpjs = $post["bpjs"];
		$this->gajibersih = $post["gajibersih"];
        $this->tanggal = $post["tanggal"];
        return $this->db->update($this->_table, $this, array('id' => $post['id']));
    }

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("id" => $id));
    }
}