<!-- Sidebar -->
<ul class="sidebar navbar-nav bg-dark">
    <li class="nav-item <?php echo $this->uri->segment(2) == '' ? 'active': '' ?>">
        <a class="nav-link" href="<?php echo site_url('admin') ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashbord</span>
        </a>
    </li>
    <li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'products' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Products</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo site_url('admin/products/add') ?>">New Product</a>
            <a class="dropdown-item" href="<?php echo site_url('admin/products') ?>">List Product</a>
        </div>
    </li>
    <li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'products' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Purchasing</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo site_url('admin/purchasing/add') ?>">New Purchasing</a>
            <a class="dropdown-item" href="<?php echo site_url('admin/purchasing') ?>">List Purchasing</a>
        </div>
    </li>
    <li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'products' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Marketing</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo site_url('admin/marketing/add') ?>">New Strategic</a>
            <a class="dropdown-item" href="<?php echo site_url('admin/marketing') ?>">List Strategic</a>
        </div>
    </li>
	<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'sales' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Sales</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo site_url('admin/sales/add') ?>">New Sales</a>
            <a class="dropdown-item" href="<?php echo site_url('admin/sales') ?>">List Sales</a>
        </div>
    </li>
	<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'payroll' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Payroll</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo site_url('admin/payroll/add') ?>">New Payroll</a>
            <a class="dropdown-item" href="<?php echo site_url('admin/payroll') ?>">List Payroll</a>
        </div>
    </li>
	<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'humanresource' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Human Resource</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo site_url('admin/humanresource/add') ?>">New Human Resource</a>
            <a class="dropdown-item" href="<?php echo site_url('admin/humanresource') ?>">List Human Resource</a>
        </div>
    </li>
	<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'accounting' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Accounting</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo site_url('admin/accounting/add') ?>">New Accounting</a>
            <a class="dropdown-item" href="<?php echo site_url('admin/accounting')?>">List Accounting</a>
        </div>
    </li>
	<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'sistemintegrasi' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Sistem integrasi</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo site_url('admin/sistemintegrasi/add') ?>">New Sistem integrasi</a>
            <a class="dropdown-item" href="<?php echo site_url('admin/sistemintegrasi')?>">List Sistem integrasi</a>
        </div>
    </li>
	<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'inventorycontrol' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Inventory Control</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo site_url('admin/inventorycontrol/add') ?>">New Inventory Control</a>
            <a class="dropdown-item" href="<?php echo site_url('admin/inventorycontrol')?>">List Inventory Control</a>
        </div>
    </li>
	<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'suratmasuk' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Surat Masuk</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo site_url('admin/suratmasuk/add') ?>">New Surat Masuk</a>
            <a class="dropdown-item" href="<?php echo site_url('admin/suratmasuk')?>">List Surat Masuk</a>
        </div>
    </li>
	<li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'suratkeluar' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Surat Keluar</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo site_url('admin/suratkeluar/add') ?>">New Surat Keluar</a>
            <a class="dropdown-item" href="<?php echo site_url('admin/suratkeluar')?>">List Surat Keluar</a>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="../logout.php">
            <i class="fas fa-fw fa-cog"></i>
            <span>Log Out</span></a>
    </li>
	
</ul>