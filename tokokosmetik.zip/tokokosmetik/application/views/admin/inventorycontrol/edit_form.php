<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>

<body id="page-top">

	<?php $this->load->view("admin/_partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("admin/_partials/sidebar.php") ?>

		<div id="content-wrapper">

			<div class="container-fluid">

				<?php $this->load->view("admin/_partials/breadcrumb.php") ?>

				<?php if ($this->session->flashdata('success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo $this->session->flashdata('success'); ?>
				</div>
				<?php endif; ?>

				<!-- Card  -->
				<div class="card mb-3">
					<div class="card-header">

						<a href="<?php echo site_url('admin/inventorycontrol/') ?>"><i class="fas fa-arrow-left"></i>
							Back</a>
					</div>
					<div class="card-body">

						<form action="" method="post" enctype="multipart/form-data">
						<!-- Note: atribut action dikosongkan, artinya action-nya akan diproses 
							oleh controller tempat vuew ini digunakan. Yakni index.php/admin/inventorycontrol/edit/ID --->

							<input type="hidden" name="id" value="<?php echo $inventorycontrol->id_invent?>" />

							<div class="form-group">
								<label for="nama_invent">Name*</label>
								<input class="form-control <?php echo form_error('nama_invent') ? 'is-invalid':'' ?>"
								 type="text" name="nama_invent" placeholder="Nama Kosmetik" value="<?php echo $inventorycontrol->nama_invent ?>" />
								<div class="invalid-feedback">
									<?php echo form_error('nama_invent') ?>
								</div>
							</div>

							<div class="form-group">
								<label for="kategori_invent">Category*</label>
								<input class="form-control <?php echo form_error('kategori_invent') ? 'is-invalid':'' ?>"
								 type="text" name="kategori_invent" min="0" placeholder="Kategori Kosmetik" value="<?php echo $inventorycontrol->kategori_invent ?>" />
								<div class="invalid-feedback">
									<?php echo form_error('kategori_invent') ?>
								</div>
							</div>

                            <div class="form-group">
								<label for="harga_invent">Price*</label>
								<input class="form-control <?php echo form_error('harga_invent') ? 'is-invalid':'' ?>"
								 type="number" name="harga_invent" placeholder="Harga Kosmetik" value="<?php echo $inventorycontrol->harga_invent ?>" />
								<div class="invalid-feedback">
									<?php echo form_error('harga_invent') ?>
								</div>
							</div>
							
							<div class="form-group">
								<label for="stock_invent">Stock*</label>
								<input class="form-control <?php echo form_error('stock_invent') ? 'is-invalid':'' ?>"
								 type="number" name="stock_invent" min="0" placeholder="Stock Kosmetik" value="<?php echo $inventorycontrol->stock_invent ?>" />
								<div class="invalid-feedback">
									<?php echo form_error('stock_invent') ?>
								</div>
							</div>

							<div class="form-group">
								<label for="tglmasuk_invent">Tanggal Masuk*</label>
								<input class="form-control <?php echo form_error('tglmasuk_invent') ? 'is-invalid':'' ?>"
								 type="date" name="tglmasuk_invent" min="0" placeholder="tglmasuk_invent" value="<?php echo $inventorycontrol->tglmasuk_invent ?>"/>
								<div class="invalid-feedback">
									<?php echo form_error('tglmasuk_invent') ?>
								</div>
							</div>
							
							<div class="form-group">
								<label for="exp_invent">Expiration*</label>
								<input class="form-control <?php echo form_error('exp_invent') ? 'is-invalid':'' ?>"
								 type="date" name="exp_invent" min="0" placeholder="Expiration" value="<?php echo $inventorycontrol->exp_invent ?>"/>
								<div class="invalid-feedback">
									<?php echo form_error('exp_invent') ?>
								</div>
							</div>

							<input class="btn btn-success" type="submit" name="btn" value="Save" />
						</form>

					</div>

					<div class="card-footer small text-muted">
						* required fields
					</div>


				</div>
				<!-- /.container-fluid -->

				<!-- Sticky Footer -->
				<?php $this->load->view("admin/_partials/footer.php") ?>

			</div>
			<!-- /.content-wrapper -->

		</div>
		<!-- /#wrapper -->

		<?php $this->load->view("admin/_partials/scrolltop.php") ?>

		<?php $this->load->view("admin/_partials/js.php") ?>

</body>

</html>