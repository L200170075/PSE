<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>

<body id="page-top">

	<?php $this->load->view("admin/_partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("admin/_partials/sidebar.php") ?>

		<div id="content-wrapper">

			<div class="container-fluid">

				<?php $this->load->view("admin/_partials/breadcrumb.php") ?>

				<?php if ($this->session->flashdata('success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo $this->session->flashdata('success'); ?>
				</div>
				<?php endif; ?>

				<div class="card mb-3">
					<div class="card-header">
						<a href="<?php echo site_url('admin/payroll/') ?>"><i class="fas fa-arrow-left"></i> Back</a>
					</div>
					<div class="card-body">

						<form action="<?php echo site_url('admin/payroll/add') ?>" method="post" enctype="multipart/form-data" >
							<div class="form-group">
								<label for="namapegawai">Nama Pegawai*</label>
								<input class="form-control <?php echo form_error('namapegawai') ? 'is-invalid':'' ?>"
								 type="text" name="namapegawai" placeholder="namapegawai" />
								<div class="invalid-feedback">
									<?php echo form_error('namapegawai') ?>
								</div>
							</div>

							<div class="form-group">
								<label for="golongan">Golongan*</label>
								<input class="form-control <?php echo form_error('golongan') ? 'is-invalid':'' ?>"
								 type="text" name="golongan" min="0" placeholder="golongan" />
								<div class="invalid-feedback">
									<?php echo form_error('golongan') ?>
								
							</div>


							<div class="form-group">
								<label for="gajipokok">gajipokok*</label>
								<input class="form-control <?php echo form_error('gajipokok') ? 'is-invalid':'' ?>"
								 type="text" name="gajipokok" min="0" placeholder="gajipokok" />
								<div class="invalid-feedback">
									<?php echo form_error('gajipokok') ?>
								</div>
							</div>
                            
							<div class="form-group">
								<label for="tunjangan">Tunjangan*</label>
								<input class="form-control <?php echo form_error('tunjangan') ? 'is-invalid':'' ?>"
								 type="text" name="tunjangan" min="0" placeholder="tunjangan" />
								<div class="invalid-feedback">
									<?php echo form_error('tunjangan') ?>
								</div>
							</div>
                            <div class="form-group">
								<label for="item">Pajak*</label>
								<input class="form-control <?php echo form_error('pajak') ? 'is-invalid':'' ?>"
								 type="text" name="pajak" min="0" placeholder="pajak" />
								<div class="invalid-feedback">
									<?php echo form_error('pajak') ?>
								</div>
							</div>
                            <div class="form-group">
								<label for="item">bpjs*</label>
								<input class="form-control <?php echo form_error('bpjs') ? 'is-invalid':'' ?>"
								 type="text" name="bpjs" min="0" placeholder="bpjs" />
								<div class="invalid-feedback">
									<?php echo form_error('bpjs') ?>
								</div>
							</div>
                            <div class="form-group">
								<label for="gajibersih">gajibersih*</label>
								<input class="form-control <?php echo form_error('gajibersih') ? 'is-invalid':'' ?>"
								 type="text" name="gajibersih" min="0" placeholder="gajibersih" />
								<div class="invalid-feedback">
									<?php echo form_error('gajibersih') ?>
								</div>
							</div>
                            
							<div class="form-group">
								<label for="date">tanggal*</label>
								<input class="form-control <?php echo form_error('tanggal') ? 'is-invalid':'' ?>"
								 type="date" name="tanggal" min="0" placeholder="tanggal" />
								<div class="invalid-feedback">
									<?php echo form_error('tanggal') ?>

								</div>
							</div>
							

							<input class="btn btn-success" type="submit" name="btn" value="Save" />
						</form>

					</div>

					<div class="card-footer small text-muted">
						* required fields
					</div>


				</div>
				<!-- /.container-fluid -->

				<!-- Sticky Footer -->
				<?php $this->load->view("admin/_partials/footer.php") ?>

			</div>
			<!-- /.content-wrapper -->

		</div>
		<!-- /#wrapper -->


		<?php $this->load->view("admin/_partials/scrolltop.php") ?>

		<?php $this->load->view("admin/_partials/js.php") ?>

</body>

</html>