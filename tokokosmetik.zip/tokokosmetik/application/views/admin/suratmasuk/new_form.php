<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>

<body id="page-top">

	<?php $this->load->view("admin/_partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("admin/_partials/sidebar.php") ?>

		<div id="content-wrapper">

			<div class="container-fluid">

				<?php $this->load->view("admin/_partials/breadcrumb.php") ?>

				<?php if ($this->session->flashdata('success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo $this->session->flashdata('success'); ?>
				</div>
				<?php endif; ?>

				<div class="card mb-3">
					<div class="card-header">
						<a href="<?php echo site_url('admin/suratmasuk/') ?>"><i class="fas fa-arrow-left"></i> Back</a>
					</div>
					<div class="card-body">

						<form action="<?php echo site_url('admin/suratmasuk/add') ?>" method="post" enctype="multipart/form-data" >
							<div class="form-group">
								<label for="tglterima_surat">Tanggal Diterima*</label>
								<input class="form-control <?php echo form_error('tglterima_surat') ? 'is-invalid':'' ?>"
								 type="date" name="tglterima_surat" placeholder="Tanggal Diterima Surat"  />
								<div class="invalid-feedback">
									<?php echo form_error('tglterima_surat') ?>
								</div>
							</div>
							
							<div class="form-group">
								<label for="pengirim_surat">Pengirim*</label>
								<input class="form-control <?php echo form_error('pengirim_surat') ? 'is-invalid':'' ?>"
								 type="text" name="pengirim_surat" placeholder="Pengirim Surat" />
								<div class="invalid-feedback">
									<?php echo form_error('pengirim_surat') ?>
								</div>
							</div>
							
							<div class="form-group">
								<label for="no_surat">Nomor Surat*</label>
								<input class="form-control <?php echo form_error('no_surat') ? 'is-invalid':'' ?>"
								 type="number" name="no_surat" placeholder="No Surat" />
								<div class="invalid-feedback">
									<?php echo form_error('no_surat') ?>
								</div>
							</div>
							
							<div class="form-group">
								<label for="tgl_surat">Tanggal Surat*</label>
								<input class="form-control <?php echo form_error('tgl_surat') ? 'is-invalid':'' ?>"
								 type="date" name="tgl_surat" placeholder="Tanggal Surat"  />
								<div class="invalid-feedback">
									<?php echo form_error('tgl_surat') ?>
								</div>
							</div>

                            <div class="form-group">
								<label for="perihal_surat">Perihal*</label>
								<input class="form-control <?php echo form_error('perihal_surat') ?'is-invalid':'' ?>"
								 type="text" name="perihal_surat" placeholder="Perihal Surat" />
								<div class="invalid-feedback">
									<?php echo form_error('perihal_surat') ?>
								</div>
							</div>


							<input class="btn btn-success" type="submit" name="btn" value="Save" />
						</form>

					</div>

					<div class="card-footer small text-muted">
						* required fields
					</div>


				</div>
				<!-- /.container-fluid -->

				<!-- Sticky Footer -->
				<?php $this->load->view("admin/_partials/footer.php") ?>

			</div>
			<!-- /.content-wrapper -->

		</div>
		<!-- /#wrapper -->


		<?php $this->load->view("admin/_partials/scrolltop.php") ?>

		<?php $this->load->view("admin/_partials/js.php") ?>

</body>

</html>