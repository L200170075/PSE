-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2020 at 06:12 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.0.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tokokosmetik1`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounting`
--

CREATE TABLE `accounting` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `harga` int(11) NOT NULL,
  `kosmetik` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounting`
--

INSERT INTO `accounting` (`id`, `nama`, `jumlah`, `tanggal`, `harga`, `kosmetik`) VALUES
(5, 'tika', 4, '2020-06-09', 200000, 'makeover'),
(5, 'avifah', 21, '2020-06-23', 50000, 'wardah');

-- --------------------------------------------------------

--
-- Table structure for table `humanresource`
--

CREATE TABLE `humanresource` (
  `id` varchar(10) DEFAULT NULL,
  `namapegawai` varchar(50) NOT NULL,
  `golongan` int(11) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `tanggalditerima` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `humanresource`
--

INSERT INTO `humanresource` (`id`, `namapegawai`, `golongan`, `jabatan`, `tanggalditerima`) VALUES
(NULL, 'putra dermawan', 2, 'customer service', '2020-06-17'),
('5ee8c0fc3a', 'tika julita', 2, 'hrd', '2020-06-17'),
('5ee8c11abf', 'fadila putri', 1, 'kepala pusat', '2020-06-17'),
('5ee8c61315', 'bunga sakura', 2, 'customer service', '2020-06-17'),
('5ee8ca484d', 'putra setiawan', 3, 'spb', '2020-06-17');

-- --------------------------------------------------------

--
-- Table structure for table `inventorycontrol`
--

CREATE TABLE `inventorycontrol` (
  `id_invent` int(11) NOT NULL,
  `nama_invent` varchar(20) NOT NULL,
  `kategori_invent` varchar(20) NOT NULL,
  `harga_invent` int(11) NOT NULL,
  `stock_invent` int(11) NOT NULL,
  `tglmasuk_invent` date NOT NULL,
  `exp_invent` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventorycontrol`
--

INSERT INTO `inventorycontrol` (`id_invent`, `nama_invent`, `kategori_invent`, `harga_invent`, `stock_invent`, `tglmasuk_invent`, `exp_invent`) VALUES
(1, 'Wardah Lightening Tw', 'Bedak', 30000, 50, '2020-06-01', '2024-01-01'),
(2, 'Make Over Perfect Sh', 'Blush On', 45000, 20, '2020-06-01', '2024-01-01'),
(3, 'Marcks', 'Moisturizer', 17000, 40, '2020-06-01', '2024-01-25'),
(4, 'Emina City Chic CC C', 'Bedak', 30000, 50, '2020-06-01', '2024-01-25'),
(6, 'PIXI UV Whitening Co', 'Foundation', 45000, 50, '2020-06-01', '2024-01-25'),
(7, 'Maybelline Fit Me!', 'Concealer', 72600, 30, '2020-06-01', '2024-01-25'),
(8, 'Focallure Highlighte', 'Highlighter & Contou', 19000, 50, '2020-06-01', '2024-01-25'),
(9, 'elf Cosmetics Baked ', 'Highlighter', 85000, 30, '2020-06-01', '2024-01-25'),
(10, 'Purbasari Oil Contro', 'Bedak', 20000, 50, '2020-06-01', '2024-01-25'),
(11, 'PIXI Twin Blush', 'Blush On', 35000, 50, '2020-06-01', '2024-01-25'),
(12, 'Viva Covering Cream', 'Cream', 10000, 50, '2020-06-01', '2024-01-25'),
(13, 'Viva Fin Touch', 'Blush On', 6000, 50, '2020-06-01', '2024-01-25'),
(14, 'Madame Gie Total Cov', 'Cushion', 20000, 40, '2020-06-01', '2024-01-25');

-- --------------------------------------------------------

--
-- Table structure for table `marketing`
--

CREATE TABLE `marketing` (
  `id` varchar(20) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `date` varchar(255) NOT NULL,
  `strategic` mediumtext NOT NULL,
  `description` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marketing`
--

INSERT INTO `marketing` (`id`, `name`, `date`, `strategic`, `description`) VALUES
('5ee4afdc8f0cf', 'aji', '2020-06-13', 'iklan di instagram', 'memasang iklan di instagram'),
('5ee4aff13af7b', 'fida', '2020-06-19', 'iklan di youtube', 'memasang iklan di youtube untuk menjangkau banyak customer'),
('5ee4b68451923', 'fida', '2020-06-18', 'Buat Konten Pemasaran', 'menggunakan strategi marketing berbasis konten pemasaran yang tetap memberi edukasi meski didalamnya tersemat pesan-pesan provokatif untuk menarik calon pembeli.  Konten pemasaran sendiri ada berbagai macam, mulai dari video, gambar, hingga artikel yang ditulis diwebsite ataupun status media sosial.'),
('5ee4b698a7d97', 'hesti', '2020-06-17', 'Tawarkan Program Refferal', 'Di dalam dunia bisnis, program refferal atau affiliasi sudah sangat umum ditemui. Strategi marketing yang satu ini bahkan bisa memberikan seseorang potensi pendapatan hingga puluhan juta rupiah per bulan hanya dari hasil menjualkan barang-barang milik orang.'),
('5ee4b6b60168e', 'titis', '2020-06-27', 'Membangun Image Brand', 'emulainya pun tidak harus selalu dengan budget serba mahal, tapi bisa dimulai dengan cara memberikan endorse atau kerjasama kecil-kecilan ke beberapa teman yang dirasa memiliki pengaruh signifikan di lingkungan sekitar.'),
('5ee4b6e1e0bdb', 'tika', '2020-06-24', 'Influencer Marketing', 'Influencer marketing sebenarnya sudah ada sejak jaman dulu, namun beberapa tahun terakhir menjadi booming akibat perkembangan sosial media yang masif. Sampai detik ini peran infuencer memang masih sangat ampuh untuk mendongkrak omzet penjualan.  Kendati demikian, Anda juga harus jeli dalam memilih serta memilah calon influencer yang akan digunakan. Jangan sampai Anda justru memilih orang yang salah sehingga mengalami kerugian waktu serta materi.'),
('5ee4b70ce6422', 'fida', '2020-06-13', 'Email Marketing', 'Perlu diketahui, strategi pemasaran melalui email marketing merupakan cara paling personal untuk menjaring calon pelanggan. Jadi jangan sekali-kali mengirimkan penawaran kepada seseorang yang alamat emailnya tidak didaftarkan secara suka rela ke layanan mailing list ');

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE `payroll` (
  `id` varchar(10) DEFAULT NULL,
  `namapegawai` varchar(100) NOT NULL,
  `golongan` int(11) NOT NULL,
  `gajipokok` varchar(100) NOT NULL,
  `tunjangan` varchar(100) NOT NULL,
  `pajak` varchar(50) NOT NULL,
  `bpjs` varchar(50) NOT NULL,
  `gajibersih` varchar(100) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payroll`
--

INSERT INTO `payroll` (`id`, `namapegawai`, `golongan`, `gajipokok`, `tunjangan`, `pajak`, `bpjs`, `gajibersih`, `tanggal`) VALUES
('5ee8c1d5c8', 'fadila putri', 1, 'Rp. 5.000.000', 'Rp. 2.000.000', 'Rp. 50.000', 'Rp. 50.000', 'Rp. 6.900.000', '2020-06-17'),
('5ee8c700bb', 'krisna aji', 3, 'Rp. 1.000.000', 'Rp. 500.000', 'Rp. 50.000', 'Rp. 50.000', 'Rp. 1.400.000', '2020-06-17'),
('5ee8c78ff3', 'arya saja ', 3, 'Rp. 3.000.000', 'Rp. 1.000.000', 'Rp. 50.000', 'Rp. 50.000', 'Rp. 3.900.000', '2020-06-17'),
('5ee8c959ac', 'tika julita', 3, 'Rp. 3.000.000', 'Rp. 1.000.000', 'Rp. 50.000', 'Rp. 50.000', 'Rp. 3.900.000', '2020-06-17');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` varchar(60) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `stock` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `price`, `stock`, `description`) VALUES
('5ee312a0e3d4e', 'emina gloss stain', 45000, 'ada', 'lip tint tahan lama'),
('5ee4b27238ead', 'Wardah Lip Cream', 45000, 'ada', 'Produk yang satu ini merupakan salah satu produk andalan Wardah. Memiliki tekstur yang creamy dan warna yang cantik, kualitas dari lip cream Wardah dapat disandingkan dengan produk sejenis dari merek luar, lho!\r\n\r\nSelain warna yang cantik, lip cream ini cepat kering dan memiliki daya tahan yang cukup lama.'),
('5ee4b285a9c8b', 'Wardah Intense Matte Lipstick', 35000, 'ada', 'Kalau perona bibir yang satu ini, lebih mengusung konsep lipstick tradisional yang berbentuk putar. Lipstik dengan jenis seperti ini lebih mudah digunakan, dan terasa lebih lembab di bibir.\r\n\r\nKalian bisa mendapatkan Wardah Intense Matte Lipstick dengan berbagai warna yang sesuai dengan warna kulit kalian dengan harga yang sangat murah.'),
('5ee4b29ab7420', 'Wardah Eyeshadow', 36000, 'ada', 'Riasan wajah tidak akan lengkap tanpa riasan mata, dengan eyeshadow dari Wardah kalian dapat membuat berbagai macam look sesuai kebutuhan. Wardah memiliki 14 varian eyeshadow dengan kombinasi warna yang berbeda.\r\n\r\nWarna yang ditawarkan oleh Wardah di dominasi oleh warna-warna netral, sehingga cocok digunakan untuk sehari-hari.'),
('5ee4b2c25a6e2', ' Emina Cheeklit Cream Blush', 29500, 'ada', 'Ingin memakai blush tapi tidak terkesan berlebihan? Emina Cheek Lit Cream Blush adalah salah satu produk yang tepat untukmu.\r\n\r\nBlush ini memiliki teksturnya juga krim berwarna putih yang mengandung squalane dan sangat mudah dibaurkan pada kulit dan setelah beberapa lama, akan mengeluarkan warna yang natural.\r\n\r\nSelain itu juga tekstur ini baik dalam mempertahankan kelembapan kulit seharian.'),
('5ee4b2d606df2', 'Emina Bare With Me Mineral Loose Powder', 30000, 'ada', 'Produk emina yang satu ini mempunyai tekstur yang halus dan coverage yang tinggi, sehingga bisa menutup ketidaksempurnaan kulit wajah dengan baik.\r\n\r\nFormulanya juga tingan dan tidak memberi hasil yang cakey. Didalam packagingnya pun juga terdapat pelindung lagi di dalamnya agar serbuk bedak tidak berhamburan ketika dibawa pergi.\r\n\r\n'),
('5ee4b2e7548b6', 'Emina Sun Protection SPF 30 PA+++', 27000, 'ada', 'Sebelum beraktivitas di luar ruangan dan mengaplikasikan makeup, jangan lupa untuk memakai sunscreen terlebih dahulu agar kulit wajah terlindungi dari paparan buruk sinar UVA dan UVB.\r\n\r\nEmina Sun Protection SPF 30 PA+++ memiliki kandungan SPF 30+++ yang akan menjaga kulit kamu dari sinar matahari.\r\n\r\nTeksturnya seperti lotion putih yang mudah diaplikasikan dan dibaurkan pada kulit dan sangat ringan di muka sehingga tidak akan terasa berat meski ditumpuk dengan makeup.\r\n\r\nSelain itu, Emina juga memperkaya produk ini dengan Emolient dan Aloe Vera Extract untuk memberikan kelembapan ekstra pada kulit. Produk ini cocok untuk kantong mahasiswa lho!'),
('5ee4b3b36336b', 'Make Over Intense Matte Lip Cream', 63000, 'ada', '1. Tekstur creamy yang ringan\r\n 2. Mudah diaplikasikan\r\n 3. Menutup bibir dalam satu kali ulas\r\n 4. Sapuan warna yang intens\r\n 5. Hasil akhir matte yang tahan lama\r\n Make Over Intense Matte Lip Cream adalah lip cream dengan bentuk liquid persembahan dari Make Over yang menghadirkan warna-warna intens dan menawan. Kini, Make Over Intense Matte Lip Cream memiliki koleksi 20 varian warna yang menarik dan lengkap, mulai dari warna-warna nudes hingga warna-warna bold yang sangat menawan. Diformulasi dengan tekstur creamy sehingga lip cream ini sangat mudah diaplikasikan. Kandungan pigmentasi warnanya yang sangat intens dapat mengcover bibir hanya dengan sekali olas. Hasil akhirnya pun matte dan terasa sangat ringan yang bahkan dapat bertahan hingga lebih dari 8 jam. \r\n  \r\n Tahan Lama Hingga 8 Jam'),
('5ee4b43b6bed0', 'Make Over Perfect Cover Two Way Cake 12 g (Refill)', 72800, 'ada', 'Refill Two Way Cake yang cocok untuk semua jenis . Hasil aplikasi yang halus dengan coverage yang mampu menyamarkan noda pada wajah. Bisa digunakan tanpa foundation. Cocok untuk penggunaan sehari-hari.'),
('5ee4b482577a8', 'Hada Labo Perfect 3D Gel', 60000, 'ada', '06 Jun 2020\r\nTeksturnya lucu seperti slime, awal-awal make masih bingung nakarnya seberapa karena bentuknya gel gitu. Tapi kalo udah dioles ke telapak tangan, gelnya mencair kayak air. '),
('5ee4b4ae2a3a6', 'Garnier Light Complete Vitamin C 30x Booster Serum Skin Care - 30 ml', 98000, 'ada', 'Garnier Light Complete Booster Serum\r\n\r\nSerum Wajah Cerah Cepat.\r\n\r\nBooster serum dengan kandungan formula pencerah tertinggi dari 30x Vitamin C dan Lemon Yuzu dari Jepang!\r\nTekstur serum ringan, cepat meresap ke lapisan kulit dan bekerja mencerahkan noda hitam.\r\n\r\nBPOM : NA18191906212\r\n\r\nShelf Life : 2 Tahun'),
('5ee4b4d3bf645', 'Garnier Light Complete White Speed Serum Day Cream Extra SPF 36/PA+++ - 50ml', 54000, 'ada', 'Cream wajah yang berfungsi untuk melindungi kulit dari sinar matahari dan membantu mencerahkan wajah dan membantu menyamarkan flek hitam pada wajah. Formula pencerah wajah yang telah disempurnakan sehingga memiliki tekstur yang lebih ringan. Diperkaya dengan 3 utama untuk kulit wajah cerah ideal yang bisa dilihat, disentuh, dan dirasakan.\r\n\r\n \r\n\r\nExpress White Complex - Kombinasi dari Snowpine C+ dan LHA yang dikenal 10x lebih kuat dari Vitamin C untuk membantu mencerahkan wajah dan menyamarkan flek hitam pada wajah. Formulanya akan membantu kulit membuat terasa halus dan pori-pori tampak kecil.\r\n\r\nPure Lemon Essence - Dikenal sebagai antioksidan alami untuk mendapatkan kulit yang sehat berseri.\r\n\r\nSPF 36/PA+++ - Perlindungan lebih tinggi terhadap sinar UVA/UVB yang dapat menyebabkan warna kulit tidak merata dan flek hitam.\r\n'),
('5ee4b4f233fbf', 'OLAY - Regenerist Micro-sculpting Serum 50ml / Day Cream 50gr', 102000, 'ada', 'Untuk jenis kulit berminyak aku rekomen pakai serum aja tanpa cream.\r\n\r\nSerum dan pelembab ini merupakan produk terlaris dalam kategori anti-aging. Efektif menyerap ke lapisan epidermis kulit, serta menghidrasi kulit agar terlihat lebih muda.\r\n\r\n+ Kulit terasa halus\r\n+ Menyamarkan garis, pori-pori, dan keriput\r\n+ Melembabkan agar kulit terasa kenyal dan kencang\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `purchasing`
--

CREATE TABLE `purchasing` (
  `id` varchar(20) DEFAULT NULL,
  `customer_name` varchar(100) NOT NULL,
  `date` varchar(255) NOT NULL,
  `item` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchasing`
--

INSERT INTO `purchasing` (`id`, `customer_name`, `date`, `item`) VALUES
(NULL, 'fida', '2020-06-13', 'wardah, emina, donat'),
('5ee48033b0378', 'yafi', '2020-07-03', 'wardah'),
('5ee4818ea18d2', 'avifah', '2020-06-20', 'wardah'),
('5ee4b228abcb8', 'fida', '2020-06-12', 'wardah'),
('5ee4b555285b5', 'fida', '2020-06-12', 'OLAY - Regenerist Micro-sculpting Serum 50ml / Day Cream 50gr'),
('5ee4b56a90014', 'avifah', '2020-06-13', 'Garnier Light Complete White Speed Serum Day Cream Extra SPF 36/PA+++ - 50ml'),
('5ee4b582116fb', 'titis', '2020-07-03', 'Garnier Light Complete Vitamin C 30x Booster Serum Skin Care - 30 ml '),
('5ee4b594ea6f3', 'tika', '2020-06-03', 'Make Over Perfect Cover Two Way Cake 12 g (Refill)'),
('5ee4b5a8ef054', 'yusinta', '2020-07-02', 'Make Over Perfect Cover Two Way Cake 12 g (Refill)'),
('5ee4b5ba35c6f', 'hesti', '2020-07-01', 'Make Over Powerstay Brow Definer Mascara.'),
('5ee4b5d1c73d3', 'jessica', '2020-07-10', 'mina Cheeklit Cream Blush'),
('5ee4b5df796c8', 'dessy', '2020-06-19', 'Emina Bare With Me Mineral Loose Powder'),
('5ee4b5f05d27b', 'yayuk', '2020-06-23', 'Emina Sun Protection SPF 30 PA+++'),
('5ee4b5fa4ae27', 'amalia', '2020-06-29', 'Emina Liquid Lip Shine – Carnation Pink'),
('5ee4b6073089c', 'aeini', '2020-06-01', 'Emina Liquid Lip Shine – Carnation Pink');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` varchar(11) DEFAULT NULL,
  `namabarang` varchar(100) NOT NULL,
  `stokbarang` int(11) NOT NULL,
  `jumlahkeluar` int(11) NOT NULL,
  `stokakhir` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `namabarang`, `stokbarang`, `jumlahkeluar`, `stokakhir`, `tanggal`) VALUES
(NULL, 'lipstik wardah', 17, 7, 10, '2020-06-17'),
('5ee8c25f2c9', 'wardah blush on', 17, 10, 7, '2020-06-17'),
('5ee8c28283f', 'face scrub emina', 50, 25, 25, '2020-06-17'),
('5ee8c2c5ef5', 'Emina gloss stain', 30, 20, 10, '2020-06-17');

-- --------------------------------------------------------

--
-- Table structure for table `sistemintegrasi`
--

CREATE TABLE `sistemintegrasi` (
  `id` varchar(20) NOT NULL,
  `produk` varchar(100) NOT NULL,
  `stok` int(100) NOT NULL,
  `jumlahterjual` int(100) NOT NULL,
  `totalbiaya` int(12) NOT NULL,
  `pengeluaran` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sistemintegrasi`
--

INSERT INTO `sistemintegrasi` (`id`, `produk`, `stok`, `jumlahterjual`, `totalbiaya`, `pengeluaran`) VALUES
('5ef4cbffc25f3', 'Wardah', 200, 54, 1900000, 200000);

-- --------------------------------------------------------

--
-- Table structure for table `suratkeluar`
--

CREATE TABLE `suratkeluar` (
  `id_surat` int(11) NOT NULL,
  `tglkeluar_surat` date NOT NULL,
  `tujuan` varchar(50) NOT NULL,
  `no_surat` int(11) NOT NULL,
  `tgl_surat` date NOT NULL,
  `perihal_surat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suratkeluar`
--

INSERT INTO `suratkeluar` (`id_surat`, `tglkeluar_surat`, `tujuan`, `no_surat`, `tgl_surat`, `perihal_surat`) VALUES
(1, '2020-01-10', 'PT. Wardah', 44, '2020-01-15', 'Permintaan Barang'),
(2, '2020-02-25', 'PT. Maybelline', 45, '2020-02-16', 'Permintaan Barang'),
(3, '2020-03-25', 'PT. Viva Kosmetik', 46, '2020-03-05', 'Permintaan Barang'),
(4, '2020-04-25', 'PT. Make Over', 47, '2020-04-16', 'Permintaan Barang'),
(6, '2020-05-20', 'PT. Focallure', 48, '2020-05-14', 'Permintaan Barang'),
(7, '2020-06-25', 'PT. Purbasari', 49, '2020-06-11', 'Permintaan Barang');

-- --------------------------------------------------------

--
-- Table structure for table `suratmasuk`
--

CREATE TABLE `suratmasuk` (
  `id_surat` int(11) NOT NULL,
  `tglterima_surat` date NOT NULL,
  `pengirim_surat` varchar(20) NOT NULL,
  `no_surat` int(11) NOT NULL,
  `tgl_surat` date NOT NULL,
  `perihal_surat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suratmasuk`
--

INSERT INTO `suratmasuk` (`id_surat`, `tglterima_surat`, `pengirim_surat`, `no_surat`, `tgl_surat`, `perihal_surat`) VALUES
(1, '2020-02-29', 'Nikmah Dwi', 5, '2020-02-12', 'Permintaan Barang'),
(2, '2020-01-10', 'Fafa Anjani', 50, '2020-01-05', 'Penawaran Produk'),
(3, '2020-03-25', 'Zaski Nur Aulia', 76, '2020-03-11', 'Lamaran Kerja'),
(4, '2020-04-25', 'Nazarudin Bahtiar', 12, '2020-04-15', 'Lamaran Kerja'),
(6, '2020-05-15', 'Anisa Putri', 43, '2020-05-04', 'Penawaran Produk'),
(7, '2020-06-25', 'Putri Nadilla', 25, '2020-06-02', 'Penawaran Produk');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `role` enum('admin','customer') NOT NULL DEFAULT 'customer',
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `photo` varchar(64) NOT NULL DEFAULT 'user_no_image.jpg',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `full_name`, `phone`, `role`, `last_login`, `photo`, `created_at`, `is_active`, `status`) VALUES
(1, 'fida', '1234', 'fidaamy65@gmail.com', 'fida amy', '6534321`', 'admin', '2020-06-12 07:59:36', 'user_no_image.jpg', '2020-06-12 07:59:36', 1, 'admin'),
(2, 'yafi', 'kopi', 'yafi@gmail.com', 'yafi nazlea', '654321', 'admin', '2020-06-12 13:55:12', 'user_no_image.jpg', '2020-06-12 13:55:12', 1, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inventorycontrol`
--
ALTER TABLE `inventorycontrol`
  ADD PRIMARY KEY (`id_invent`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `suratkeluar`
--
ALTER TABLE `suratkeluar`
  ADD PRIMARY KEY (`id_surat`);

--
-- Indexes for table `suratmasuk`
--
ALTER TABLE `suratmasuk`
  ADD PRIMARY KEY (`id_surat`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inventorycontrol`
--
ALTER TABLE `inventorycontrol`
  MODIFY `id_invent` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `suratkeluar`
--
ALTER TABLE `suratkeluar`
  MODIFY `id_surat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `suratmasuk`
--
ALTER TABLE `suratmasuk`
  MODIFY `id_surat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
